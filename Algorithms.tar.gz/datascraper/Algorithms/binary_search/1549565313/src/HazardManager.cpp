#include "HazardManager.hpp"

__thread unsigned int thread_num;
