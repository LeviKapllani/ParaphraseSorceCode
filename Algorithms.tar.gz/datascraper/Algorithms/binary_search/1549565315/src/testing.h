/*
 * testing.h
 *
 *  Created on: 19Sep.,2016
 *      Author: mark
 */




#ifndef TESTING_H_
#define TESTING_H_

#include <vector>

using namespace std;

const char * testFile();
void checkSAandLCP(vector<int> SA, vector<int> LCP);

#endif /* TESTING_H_ */
