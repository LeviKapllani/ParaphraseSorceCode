/*
 * MemUsage.h
 *
 *  Created on: 26Sep.,2016
 *      Author: mark
 */

#ifndef MEMUSAGE_H_
#define MEMUSAGE_H_

void process_mem_usage(double& vm_usage, double& resident_set);

#endif /* MEMUSAGE_H_ */
