#include "Test.h"
#include <iostream>
#include "Edge.h"

using namespace std;

int** getKruskalMST(int** graph, int size, vector<Edge*> edges)
{
    return NULL;
}

int main ()
{
    test();
    return 0;
}
