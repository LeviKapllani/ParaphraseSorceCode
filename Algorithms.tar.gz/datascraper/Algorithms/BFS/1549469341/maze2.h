#ifndef maze2_h
#define maze2_h

class Node
{
	int row;
	int col;
};

#endif