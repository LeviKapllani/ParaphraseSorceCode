﻿// Dijkstra's Algorithm.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
using namespace std;
#define Name_Length 15 //Determines maximum length of city name minus one


class City
{
public:
	char* name; //Name of a city
	char* w; //Way from source to a city, shortest or fastest, depends on function
	int d; //Distance of the shortest way
	int t; //Time it took to cover fastest way

private:

};

void Check_City(const char *q, char *Array[], int &n) //Creates Array of unique city names
{
	for (int i = 0; i < n; i++)
	{
		if (int((strcmp(q, Array[i])) == 0))
		{
			return;
		}
	}
	Array[n] = new char[Name_Length];
	if (Array[n] == NULL)
	{
		throw "Failed to allocate memory";
	}
	strcpy_s(Array[n], Name_Length, q);
	n++;
}

void Create_Cities(City *City_Array, int n, char *Array[]) //Create n <cities> structures
{

	for (int i = 0; i < n; i++)
	{
		City_Array[i].name = (char*)new char[Name_Length];
		strcpy(City_Array[i].name, Array[i]);
		City_Array[i].w = (char*)new char[((Name_Length + 2)*n)];
		strcpy(City_Array[i].w, "");
		City_Array[i].d = 1000000;//Since this program is not designed for space travel, I guess milion km is close enough to infinity
		City_Array[i].t = 1000000;//See above
	}
}

void Reset_Cities(City *City_Array, int n)
{
	for (int i = 0; i < n; i++)
	{
		strcpy(City_Array[i].w, "");
		City_Array[i].d = 1000000;
		City_Array[i].t = 1000000;
	}
}

void Load_Distances(int **Distance_Array, char *Array[], int **Time_Array, int s, int &n) //Program assumes that input is in |City_A City_B Distance Average_Speed| format
{// Function reads from file both distances and average speeds, then creates Arrays of distances and times of travel
	int u, v;
	FILE *f;
	fopen_s(&f, "Distances.txt", "r");
	if (f == NULL)
	{
		cout << "<<<No such file or directory, please check if program location contains \"Distances.txt.\">>>" << endl;
		s = 4;
		return;
	}
	char *p;//Pointer for strtok
	const char *r;//Pointer for strtok
	char *x;//Pointer for fgets
	char buff[3 * Name_Length]; //Buffer for fgets
	double tmp;
	do
	{
		x = fgets(buff, 3 * Name_Length, (FILE*)f); //Gets single line from a file
		if (x != NULL)
		{
			try 
			{
				r = strtok_s(x, " ", &p); //Gets characters from said line, until it encounters " "
				Check_City(r, Array, n);
				r = strtok_s(NULL, " ", &p);// strtok happens two times, cause we know that file is in |City_A City_B Distance Max_Speed| format, so first two entries on each line are cities 
				Check_City(r, Array, n);
			}
			catch (const char)
			{
				cerr << "Failed to allocate memory" << endl;
				s = 4;
				break;
			}
		}
	} while (x != NULL);
	//We have Array with pointers to strings with unique names of the cities

	for (int i = 0; i < n; i++)
	{
		Distance_Array[i] = (int*)new int[n]; //Creating 2d Array of size n*n, while n is equal to number of cities
	}

	for (int i = 0; i < n; i++)
	{
		Time_Array[i] = (int*)new int[n]; //Creating 2d Array of size n*n, while n is equal to number of cities
	}
	for (int i = 0; i < n; i++)//Setting all values that won't be defined to -1
	{
		for (int j = 0; j < n; j++)
		{
			if (i == j)
			{
				Distance_Array[i][j] = 0; // Both distance, and time from A to A shall be 0
				Time_Array[i][j] = 0;
			}
			else
			{
				Distance_Array[i][j] = -1;
				Time_Array[i][j] = -1;
			}
		}
	}
	rewind(f);
	do //Now getting values into distance and time Array
	{
		x = fgets(buff, 3 * Name_Length, (FILE*)f); //Gets single line from a file
		if (x != NULL)
		{
			r = strtok_s(x, " ", &p); //Gets characters from said line, until it encounters " "
			for (int i = 0; i < n; i++)
			{
				if (int((strcmp(r, Array[i])) == 0))
				{
					u = i;
					break;
				}
			}
			r = strtok_s(NULL, " ", &p);
			for (int i = 0; i < n; i++)
			{
				if (int((strcmp(r, Array[i])) == 0))
				{
					v = i;
					break;
				}
			}
			r = strtok_s(NULL, " ", &p);
			tmp = int(strtoimax(r, NULL, 0));
			Distance_Array[v][u] = tmp;
			Distance_Array[u][v] = Distance_Array[v][u];
			r = strtok_s(NULL, " ", &p);
			tmp = int(strtoimax(r, NULL, 0));
			Time_Array[v][u] = (((Distance_Array[u][v]) / tmp) * 60) + 1; //Travel time is stored in minutes, I could've made Array of doubles to store minutes including after the decimal point, but I decided against it, hence +1
			Time_Array[u][v] = Time_Array[v][u];
		}
	} while (x != NULL);
	fclose(f);
}

void Engage_Short_Dijkstra(int **Distance_Array, char *Array[], City *City_Array ,int n, int u, int v)
{
	int *Current_arr;
	int *Next_arr;
	int Sroute = 0;//If algorith is finished it's set to 1, breaking while loop
	int c = 0;//Counter for Next_arr
	Current_arr = (int*)new int[n];
	Next_arr = (int*)new int[n];
	for (int i = 0; i < n; i++)
	{
		Current_arr[i] = -1;
		Next_arr[i] = -1;
	}
	Next_arr[0] = u;
	City_Array[u].d = 0;
	strcpy(City_Array[u].w, Array[u]);
	strncat(City_Array[u].w, ", ", 5);
	while (Sroute != 1)
	{
		c = 0;
		for (int i = 0; i < n; i++)
		{
			Current_arr[i] = Next_arr[i];
			Next_arr[i] = -1;
		}
		for (int i = 0; i < n; i++)
		{
			if (Current_arr[i] > -1)
			{
				u = Current_arr[i];//Currently calculated city
				for (int j = 0; j < n; j++)
				{
					if (Distance_Array[u][j] > 0)
					{
						if (int(City_Array[u].d + Distance_Array[u][j]) < int(City_Array[j].d))
						{
							City_Array[j].d = City_Array[u].d + Distance_Array[u][j];
							strncpy(City_Array[j].w, City_Array[u].w, (Name_Length*n));
							strncat(City_Array[j].w, Array[j], (Name_Length*n));
							strncat(City_Array[j].w, ", ", (Name_Length*n));
							Next_arr[c] = j;
							c++;
						}
					}
				}
			}
		}
		if (Next_arr[0] == -1)
		{
			Sroute = 1;
			break;
		}
	}
	cout << City_Array[v].d << " km" << endl;
	cout << "The way leads through: " << City_Array[v].w << endl;
	delete(Current_arr);
	delete(Next_arr);
	Reset_Cities(City_Array, n);
}

void Engage_Fast_Dijkstra(int **Time_Array, char *Array[], City *City_Array, int n, int u, int v)
{
	int *Current_arr;
	int *Next_arr;
	int Sroute = 0;//If algorith is finished it's set to 1, breaking while loop
	int c = 0;//Counter for Next_arr
	Current_arr = (int*)new int[n];
	Next_arr = (int*)new int[n];
	for (int i = 0; i < n; i++)
	{
		Current_arr[i] = -1;
		Next_arr[i] = -1;
	}
	Next_arr[0] = u;
	City_Array[u].t = 0;
	strcpy(City_Array[u].w, Array[u]);
	strncat(City_Array[u].w, ", ", 5);
	while (Sroute != 1)
	{
		c = 0;
		for (int i = 0; i < n; i++)
		{
			Current_arr[i] = Next_arr[i];
			Next_arr[i] = -1;
		}
		for (int i = 0; i < n; i++)
		{
			if (Current_arr[i] > -1)
			{
				u = Current_arr[i];//Currently calculated city
				for (int j = 0; j < n; j++)
				{
					if (Time_Array[u][j] > 0)
					{
						if (int(City_Array[u].t + Time_Array[u][j]) < int(City_Array[j].t))
						{
							City_Array[j].t = City_Array[u].t + Time_Array[u][j];
							strncpy(City_Array[j].w, City_Array[u].w, (Name_Length*n));
							strncat(City_Array[j].w, Array[j], (Name_Length*n));
							strncat(City_Array[j].w, ", ", (Name_Length*n));
							Next_arr[c] = j;
							c++;
						}
					}
				}
			}
		}
		if (Next_arr[0] == -1)
		{
			Sroute = 1;
			break;
		}
	}
	cout << ((City_Array[v].t) / 60) << ":" << ((City_Array[v].t) % 60) << endl;
	cout << "The way leads through: " << City_Array[v].w << endl;
	delete(Current_arr);
	delete(Next_arr);
	Reset_Cities(City_Array, n);
}

void Check_City_Name(char *Array[], int n, int &x)
{
	x = -1;
	char name[Name_Length];
	cin >> name;
	cin.clear();
	cin.ignore(100, '\n');

	for (int i = 0; i < n; i++)
	{
		if ((strcmp(name, Array[i])) == 0)
		{
			x = i;
			break;
		}
	}
	if (x == -1)
	{
		cout << "Please try again" << endl;
		Check_City_Name(Array, n, x);
		name[0] = '\n';
	}
}

void Check_Short_Neighbourhood(int** Distance_Array, char *Array[], City *City_Array, char c, int n, int r)
{
	int u, v;
	cout << "Please input city you want to reach, then press <Enter>: " << endl;
	Check_City_Name(Array, n, u);


	cout << "Please input city of departure, then press <Enter>: " << endl;
	Check_City_Name(Array, n, v);


	if (Distance_Array[u][v] == 0)
	{
		cout << "You are where you want to be!\n" << endl;
	}
	else if (Distance_Array[u][v] > 0)
	{
		cout << "Shortest way from " << Array[u] << " to " << Array[v] << " is: " << Distance_Array[u][v] << "km" << endl;
		cout << "There is a direct route between these cities." << endl;
	}
	else
	{
		cout << "Shortest way from " << Array[u] << " to " << Array[v] << " is: ";
		Engage_Short_Dijkstra(Distance_Array, Array, City_Array, n, u, v);
	}
}

void Check_Fast_Neighbourhood(int** Time_Array, char *Array[], City *City_Array, char c, int r, int n)
{
	int u, v;
	cout << "Please input city you want to reach, then press <Enter>: " << endl;
	Check_City_Name(Array, n, u);

	/*

	r = scanf("%s", q);
	if (r == 0)
	{
		while ((c = getchar()) != '\n' && c != EOF)
		{
			getchar();
		}
		cout << "Invalid input" << endl;
		Check_Fast_Neighbourhood(n, q, r, Array, c, Time_Array, City_Array);
	}
	else
	{
		while ((c = getchar()) != '\n' && c != EOF)
		{
			getchar();
		}
	}
	for (int i = 0; i < n; i++)
	{
		if (int((strcmp(q, Array[i])) == 0))
		{
			u = i;
			break;
		}
	}
	*/

	cout << "Please input city of departure, then press <Enter>: " << endl;
	Check_City_Name(Array, n, v);

	if (Time_Array[u][v] == 0)
	{
		cout << "\nYou are where you want to be!" << endl;
	}
	else if (Time_Array[u][v] > 0)
	{
		cout << "\nFastest way from " << Array[u] << " to " << Array[v] << " it takes: " << ((Time_Array[u][v]) / 60) << ":" << ((Time_Array[u][v]) % 60) << endl;
		cout << "There is a direct route between these cities." << endl;
	}
	else
	{
		cout << "\nFastest way from " << Array[u] << " to " << Array[v] << " is ";
		Engage_Fast_Dijkstra(Time_Array, Array, City_Array, n, u, v);
	}
}

void Print_Cities(char *Array[], int n)
{
	cout << "List of cities:" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << Array[i] << endl;
	}
}

void Interface(int** Distance_Array, int **Time_Array, char *Array[], City *City_Array, char c, int n, int r, int s)
{
	if (s != 4)
	{
		cout << "Welcome to Dijkstra's Algorithm" << endl;
	}
	while (s != 4)
	{
		cout << "=====================================================" << endl;
		cout << "" << endl;
		cout << "1. Find shortest way between two cities" << endl;
		cout << "2. Find fastest way between two cities" << endl;
		cout << "3. Show list of possible cities" << endl;
		cout << "4. Exit" << endl;
		cout << "Please choose number related to action you want to preform and press <Enter> to confirm: " << endl;
		r = scanf("%1d", &s);
		if (r == 0)
		{
			while ((c = getchar()) != '\n' && c != EOF)
			{
				getchar();
			}
			continue;
		}
		else
		{
			while ((c = getchar()) != '\n' && c != EOF)
			{
				getchar();
			}
		}
		if (s == 1)
		{
			Check_Short_Neighbourhood(Distance_Array, Array, City_Array, c, n, r);
		}
		else if (s == 2)
		{
			Check_Fast_Neighbourhood(Time_Array, Array, City_Array, c, r, n);
		}
		else if (s == 3)
		{
			Print_Cities(Array, n);
		}
		else if (s == 4)
		{
			cout << "You choose to exit the program. Shutting down" << endl;
			break;
		}
		else
		{
			cout << "\nInvalid input. Please try again\n" << endl;
			s = 0;
		}
	}
}

int main()
{
	int n = 0; //Stores number of cities
	char *Array[10000]; //Array of pointers to strings with names od cities, from what i've seen it takes as much memory as *Array[1], so I put 10k just to be sure to contain huge number of cities
	int** Distance_Array; //Array of distances between cities
	int** Time_Array; //Array of time of travel between cities
	City *City_Array; //Pointer for Array of cities

	int r = 0;
	char c = 0;
	int s = 0;

	Distance_Array = (int**)new int*[n];
	Time_Array = (int**)new int*[n];
	City_Array = (City*)new City[n];

	Load_Distances(Distance_Array, Array, Time_Array, s, n);
	Create_Cities(City_Array, n, Array);

	Interface(Distance_Array, Time_Array, Array, City_Array, c, n, r, s);
	return 0;
}