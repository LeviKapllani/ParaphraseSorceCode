#include "../inc/vertex.hpp"

Vertex::Vertex(const string & newLabel)
{
    label = newLabel;
}

void Vertex::addNeighbours(const set<Vertex::V> & n)
{
    for (const auto & v: n)
    {
        v->addParent(shared_from_this());
        neighbours.insert(v);
    }
}

void Vertex::addParent(const Vertex::V & p)
{
    parents.insert(p);
}

void Vertex::deleteParent(const Vertex::V & p)
{
    parents.erase(p);
}

size_t Vertex::inDeg() const
{
    return parents.size();
}

string Vertex::getLabel() const
{
    return label;
}

set<Vertex::V> & Vertex::getNeighbours()
{
    return neighbours;
}