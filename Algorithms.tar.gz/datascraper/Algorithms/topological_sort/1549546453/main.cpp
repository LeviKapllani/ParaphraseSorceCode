#include <iostream>
#include <vector>
#include <queue>
#include "inc/vertex.hpp"

using namespace std;
using V = Vertex::V;

vector<V> topologicalSort(const set<V> & graph)
{
    vector<V> sortedGraph;
    queue<V> Q;

    for (const auto & v: graph)
    {
        if (v->inDeg() == 0)
        {
            Q.push(v);
        }
    }

    while (not Q.empty())
    {
        auto & v = Q.front();
        Q.pop();

        sortedGraph.push_back(v);

        for (auto & u: v->getNeighbours())
        {
            u->deleteParent(v);
            if (u->inDeg() == 0)
            {
                Q.push(u);
            }
        }
    }

    return sortedGraph;
}

int main()
{
    VertexFactory factory;

    V a = factory.create("a");
    V b = factory.create("b");
    V c = factory.create("c");
    V d = factory.create("d");
    V e = factory.create("e");
    V f = factory.create("f");
    V g = factory.create("g");
    V h = factory.create("h");

    a->addNeighbours({d});
    b->addNeighbours({d, e});
    c->addNeighbours({e, h});
    d->addNeighbours({f, g, h});
    e->addNeighbours({g});
    g->addNeighbours({h});

    for (const auto & v: topologicalSort({h, d, a, c, f, b, e, g}))
    {
        cout << v->getLabel() << " ";
    }

}
