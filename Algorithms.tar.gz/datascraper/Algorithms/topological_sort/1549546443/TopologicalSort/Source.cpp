#include<iostream>
#include "topologicalSort.h"
int main()
{
	int V = 6;
	int E = 6;

	list<int> *adj = new list<int>[V];

	adj[5].push_back(2);
	adj[5].push_back(0);
	adj[4].push_back(0);
	adj[4].push_back(1);
	adj[2].push_back(3);
	adj[3].push_back(1);

	Graph *g = new Graph(V, E, adj);

	topologicalSort *ts = new topologicalSort(g);
	cout << "Following is a Topological Sort of the given graph " << endl;
	ts->topologicalOrder();

	getchar();
	return 0;
}