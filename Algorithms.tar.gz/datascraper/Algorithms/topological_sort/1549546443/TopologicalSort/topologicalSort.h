#pragma once
#include<stack>
#include<list>
#include "Graph.h"
using namespace std;
class topologicalSort
{
public:
	topologicalSort(Graph *g)
	{
		this->g = g;
	}
	~topologicalSort()
	{
		delete g;
	}
	void topologicalOrder()
	{
		stack<int> Stack;
		bool *visited = new bool[g->getV()];
		memset(visited, false, g->getV());
		for (int i = 0; i < g->getV(); i++)
		{
			if (visited[i] == false)
			{
				topologicalSortUtil(i, visited, Stack);
			}
		}
		print(Stack);
	}

private:
	Graph * g;
	void topologicalSortUtil(int v, bool visited[], stack<int> &Stack)
	{
		visited[v] = true;
		for (auto i = g->getAdj()[v].begin(); i != g->getAdj()[v].end(); ++i)
		{
			if (!visited[*i])
			{
				topologicalSortUtil(*i, visited, Stack);
			}
		}
		Stack.push(v);
	}
	void print(stack<int>Stack)
	{
		while (Stack.empty() == false)
		{
			cout << Stack.top() << " ";
			Stack.pop();
		}
	}
};