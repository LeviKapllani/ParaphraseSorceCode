#pragma once
#include<iostream>
#include<vector>
#include<list>
#include<stdexcept>
using namespace std;
class Graph
{
private:
	int V = 0;
	int E = 0;
	list<int>* adj;
public:
	Graph(int v, int e, list<int>* adj)
	{
		try
		{
			this->V = v;
			if (V < 0)
			{
				throw invalid_argument("number of vertices in a Graph must be nonnegative");
			}
			this->E = e;
			if (E < 0)
			{
				throw std::invalid_argument("number of edges in a Graph must be nonnegative");
			}
			this->adj = adj;
		}
		catch (const exception& e)
		{
			cout << "invalid input format in Graph constructor." << e.what() << endl;
		}
	}
	~Graph()
	{
		V = 0;
		E = 0;
		adj->~list();
	}
	int getV()
	{
		return V;
	}
	int getE()
	{
		return E;
	}
	list<int> * getAdj()
	{
		return adj;
	}
	void setV(int v)
	{
		this->V = v;
	}
	void setE(int e)
	{
		this->E = e;
	}
	void setAdj(list<int>*adj)
	{
		this->adj = adj;
	}
};