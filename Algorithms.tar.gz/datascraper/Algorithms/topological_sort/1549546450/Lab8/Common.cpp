#include "Common.h"

const char* ErrorMessages::MEMORY_ERROR = "Can't allocate memory";
const char* ErrorMessages::FILE_OPEN_ERROR = "Can't open file";
const char* ErrorMessages::WRONG_INPUT_ERROR = "Wrong input format.";

