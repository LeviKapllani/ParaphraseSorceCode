/******************************************************************************/
/*
*     Name          :     Jason Dietrich
*     Class         :     CSCI 311-03
*     Date          :     <05/04/12>
*/
/******************************************************************************/

/**
    network.h
    description: contains the class definition for Network as well as struct definitions for Edge and Vertex
*/

#include <algorithm>
#include <list>
#include <queue>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

/**
    Edge: represents a connection between two vertices in the network. Contains source and end
    vertices which are integer values that correspond to an index within a Network object's vertex
    vector. Weight represents the relative cost of traversing the edge.

*/
struct Edge
{
    int source;
    int destination;
    int weight;
};

/**
    Vertex: contains a list of adjoining vertices connected by edges.
*/
struct Vertex
{
    list <Edge> connection;
};

/**
    Network: a class to build and manage a graph of interconnected vertices. A network object is initialized
    with a given number of vertices and whether or not the graph is symmetrical which means that all edges added
    will also have an equal and opposite edge.
*/
class Network
{
    public:

        //default constructor not used
        Network ();

    /**
        constructor: Network
        description: resizes the vector of vertices to be the number in vertexCount, sets symmetry condition
        @param vertexCount the number of vertices in the graph
        @param symmetry whether or not this graph will have symmetric edges added automatically
    */
        Network (int vertexCount, bool symmetry = true);

        //destructor does nothing
        ~Network ();

    /**
        function: addEdge
        description: adds an edge of a certain weight between a source vertex and end vertex
        @param source specifies the index of the starting vertex of an edge
        @param end specifies the index of the ending vertex of an edge
        @param weight specifies the cost associated with traversing the edge
    */
        void addEdge (int source, int end, int weight);

    /**
        function: getMinSpanTree
        description: builds and returns the minimum spanning tree of this network as a network using Prim's algorithm.
        @return returns a string containing all the edges in the minimum spanning tree for this network
        @param source specifies root index of minimum spanning tree
    */
        string getMinSpanTree (int source);

    /**
        function: printEdges
        description: generates a string containing each vertex and its respective edges on separate lines
        @return returns the source, destination and weight of every edge in this network
    */
        string printEdges ();

    /**
        function: getMinWeight
        description: returns an integer containing the total weight of the min spanning tree for this network
        pre: a call to getMinSpanTree must be performed for this function's return to be valid
    */
        int getMinWeight ();

    private:

    /**
        operator: <
        description: used by priority queue to determine which edge to take next. Gives higher priority to lower edge weights
        followed by lower source vertices.
        @param edge on left side of <
        @param edge on right side of <
        @return returns true if first has a higher edge weight than second. In the event of a tie returns true
                if first has a higher source vertex than second.
    */
        friend bool operator <(const Edge& first, const Edge& second);

        bool valid (unsigned int vertexID);     //tests if vertexID is in the range from [0 - highest_vertex_ID]

        list<Edge>::iterator it;                //used to cycle through vertex connection list

        vector<Vertex> vertices;                //vertices that make up this network

        bool symmetric;                         //all edges are symmetric

        int minWeight;                          //total weight of minimum spanning tree
};


