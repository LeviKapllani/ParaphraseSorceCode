/******************************************************************************/
/*
*     Name          :     Jason Dietrich
*     Class         :     CSCI 311-03
*     Date          :     <05/04/12>
*/
/******************************************************************************/

/**
    CSCI-311 Project 3 Graphs/Prim's Algorithm
    @author Jason Dietrich

    main.cpp
    description - this is the test program for Prim's minimal spanning tree algorithm. Two command line
    arguments are needed to specify the input and output files to use. A network object is then created
    and edges are passed in from the input file. After all the edges have been read in, the program
    reads in source vertices from the input file and generates a minimal spanning tree from each given
    source vertex to every other vertex, the resulting trees are written to the output file.

    command line: <string> input_file, <string> ouput_file

    Input file format: the first line of the input file specifies the number of vertices that the
    graph (network) will contain. The lines following specify edges within the graph (network).
    After the last edge is a blank line followed by source vertices from which to find the minimal
    spanning tree.

        first line:     <integer> vertices_in_graph

        edge:           <integer> start_vertex, <integer> end_vertex, <integer> edge_weight

        source:         <integer> source_vertex


*/

#include <algorithm>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include "network.h"
using namespace std;
int main(int argc, char* argv[])
{
    ifstream fin;
    ofstream fout;
//
//  test file maker start
//
/*
    srand (time (NULL));
    fout.open(argv[1]);
    int vertices = 50, edgeMax = 7, weightMax = 9;
    fout << vertices << endl;

    int times_visited[vertices];
    fill(times_visited, times_visited+vertices, 0);

    for (int i=0; i<vertices; i++)
    {
        int edges = rand()%edgeMax + 1;
        bool visited[vertices];
        fill(visited, visited+vertices, false);
        visited[i] = true;

        for (int j=0; j<edges; j++)
        {
            int end;
            do end    = rand()%vertices;
            while (visited[end] == true || times_visited[end] > edgeMax);
            visited[end] = true;
            times_visited[end]++;
            int weight = rand()% weightMax + 1;
            fout << i << " " <<  end << " " << weight << endl;
        }
    }

    fout << endl << "0" << endl;
    fout.close();
*/

//
//  program start
//
    fin.open(argv[1]);
    if (!fin.fail())
    {
        fout.open(argv[2]);
        if (!fout.fail())
        {
            int vertexCount;
            fin >> vertexCount;
            Network net (vertexCount, true);

            int newSource, newEnd, newWeight;

            cout << "Reading edges...\n";
            fin >> newSource;
            while (fin >> newEnd)
            {
                fin >> newWeight;
                net.addEdge(newSource, newEnd, newWeight);
                fin >> newSource;
            }

            cout << "Your graph contains:\n";
            cout << net.printEdges();

            fout << "Your graph contains:\n";
            fout << net.printEdges();

            string mstree = net.getMinSpanTree(newSource);

            cout << "Min span tree from: " << newSource << " has weight " <<  net.getMinWeight() << endl;
            cout << mstree << endl;

            fout << "Min span tree from: " << newSource << " has weight " <<  net.getMinWeight() << endl;
            fout << mstree << endl;

            cout << "Complete!";
        }
        else cout << "Could not open output file.\n";
    }
    else cout << "Could not open input file.\n";

    return 0;
}
