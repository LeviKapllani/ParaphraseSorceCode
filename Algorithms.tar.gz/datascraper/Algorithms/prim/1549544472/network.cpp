/******************************************************************************/
/*
*     Name          :     Jason Dietrich
*     Class         :     CSCI 311-03
*     Date          :     <05/04/12>
*/
/******************************************************************************/

#include "network.h"

Network::Network(){}

Network::Network (int vertexCount, bool symmetry)
{
    vertices.resize (vertexCount);
    symmetric = symmetry;
}

Network::~Network(){}

void Network::addEdge (int source, int end, int weight)
{
    if (valid(source) && valid(end))
    {
        Edge newEdge;
        newEdge.source = source;
        newEdge.destination = end;
        newEdge.weight = weight;
        vertices[source].connection.push_back(newEdge);
        if (symmetric)
        {
            newEdge.destination = source;
            newEdge.source = end;
            vertices[end].connection.push_back (newEdge);
        }
    }
}

string Network::getMinSpanTree (int source)
{
    if (valid (source)){

        Network minSpanTree(vertices.size(), true);
        priority_queue <Edge> pathQueue;

        vector <bool> visited (vertices.size());
        fill(visited.begin(), visited.end(), false);

        minWeight = 0;

        for (it = vertices[source].connection.begin(); it!=vertices[source].connection.end(); it++)
        {// heapify edges from source vertex
            pathQueue.push (*it);
        }

        while ( (count (visited.begin(), visited.end(), 0) > 0) && !pathQueue.empty() )
        {
            Edge bestEdge = pathQueue.top();

            visited[bestEdge.source]        = true;
            visited[bestEdge.destination]   = true;

            minSpanTree.addEdge(bestEdge.source, bestEdge.destination, bestEdge.weight);
            minWeight += bestEdge.weight;

            for (it = vertices[bestEdge.destination].connection.begin();
                    it!=vertices[bestEdge.destination].connection.end(); it++)
            {
                pathQueue.push (*it);
            }

            //remove edges from consideration that would create a circuit
            while ( !pathQueue.empty() && visited [pathQueue.top().destination] == true)  pathQueue.pop();
        }
        return minSpanTree.printEdges();
    }
    else return "Invalid source vertex\n";
}

string Network::printEdges()
{
    stringstream out;
    for (unsigned int i=0; i<vertices.size(); i++)
    {
        out << i;
        for (it = vertices[i].connection.begin(); it!=vertices[i].connection.end(); it++)
        {
            out << " ->" << it->destination << "|" << it->weight;
        }
        out << "\n";
    }
    return out.str();
}

int Network::getMinWeight ()
{
    return minWeight;
}

bool Network::valid (unsigned int vertexID)
{
    if (vertexID >= 0 && vertexID < vertices.size())
        return true;
    else
        return false;
}

bool operator <(const Edge& first, const Edge& second)
{
    if      (first.weight != second.weight)  return (first.weight > second.weight);
    else                                     return (first.source > second.source);

}
