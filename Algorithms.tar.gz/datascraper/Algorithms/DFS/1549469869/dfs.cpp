#include<iostream>
#include<stack>
using namespace std;
int main()
{
    stack<int>s1;
    int G[100][100];
    int visit[100];
    int n;
    int e;
    cin>>n>>e;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            G[i][j]=0;
            visit[i]=0;
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            cout<<G[i][j]<<" ";
        }
        cout<<"\n";
    }
    for(int i=1;i<=e;i++)
    {
        int s;
        int d;
        cin>>s>>d;
        G[s][d]=1;
        G[d][s]=1;
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n;j++)
        {
            cout<<G[i][j]<<" ";
        }
        cout<<"\n";
    }
    int source,flag=0;
    cin>>source;
    s1.push(source);
    visit[source]=1;
    cout<<s1.top();

    int i,c=0;
    while(!s1.empty())
    {
        flag=0;
        int k=s1.top();
      //  s1.pop();
        for(i=1;i<=n;i++)
        {
            if(G[k][i]==1)
            {
                if(visit[i]==0)
                {
                    flag=1;
                    s1.push(i);
                    cout<<i;
                    visit[i]=1;
                     break;
                }

            }
        }

        if(flag==0 && i-1==n)
        {

            s1.pop();
        }

    }
}
