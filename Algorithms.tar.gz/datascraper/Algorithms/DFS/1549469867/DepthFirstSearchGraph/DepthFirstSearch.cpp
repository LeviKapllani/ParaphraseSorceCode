//
//  DepthFirstSearch.cpp
//  DepthFirstSearchGraph
//
//  Created by Shivsankar Ramasubramanian on 1/5/16.
//  Copyright © 2016 Shivsankar Ramasubramanian. All rights reserved.
//

#include "DepthFirstSearch.hpp"
#include <list>
#include <iostream>

using namespace std;

Graph::Graph(int V)
{
    this->V = V;
    theArray = new list<int>[V];
}

void Graph::addEdge(int v, int w)
{ theArray[v].push_back(w); }

void Graph::DFSUtil(int s, bool visited[])
{
    visited[s] = true;
    cout<<s<<" ";
    
    list<int>::iterator i;
    for (i=theArray[s].begin(); i!=theArray[s].end(); ++i)
    {
        if (!visited[*i])
            DFSUtil(*i, visited);
    }
}

void Graph::DFS()
{
    bool *visited = new bool[V];
    for (int i=0; i<V; i++)
        visited[i] = false;
    //DFSUtil(s, visited);
    for (int i=0; i<V; i++)
    {
        if (visited[i]==false)
                DFSUtil(i, visited);
        cout<<"\n";
    }
    delete [] visited;
}

Graph::~Graph()
{ delete [] theArray; }







