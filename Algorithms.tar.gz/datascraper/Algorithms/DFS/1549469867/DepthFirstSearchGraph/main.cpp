//
//  main.cpp
//  DepthFirstSearchGraph
//
//  Created by Shivsankar Ramasubramanian on 1/5/16.
//  Copyright © 2016 Shivsankar Ramasubramanian. All rights reserved.
//

#include <iostream>
#include <list>
#include "DepthFirstSearch.hpp"

using namespace std;

int main(int argc, const char * argv[])
{
    Graph g(4);
    
    //g.addEdge(2,0);
    //g.addEdge(0,2);
    g.addEdge(0,1);
    g.addEdge(2,3);
    g.addEdge(3,3);
    g.addEdge(1,2);
    
    g.DFS();
    
    return 0;
}
