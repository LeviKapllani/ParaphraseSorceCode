#include "DepthFirstSearch.h"
int main()
{
	Graph *G = new Graph("tinyG.txt");
	int s = 9;
	DepthFirstSearch *search = new DepthFirstSearch(G, s);
	for (int v = 0; v < G->V(); v++)
	{
		if (search->marked(v))
		{
			cout << v << " ";
		}
	}
	cout << endl;
	if (search->count() != G->V())
	{
		cout << "NOT connected" << endl;
	}
	else
	{
		cout << "connected" << endl;
	}

	getchar();
	return 0;
}