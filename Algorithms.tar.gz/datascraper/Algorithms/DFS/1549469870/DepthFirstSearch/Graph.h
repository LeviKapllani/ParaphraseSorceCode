#pragma once
#include<iostream>
#include<fstream>
#include<vector>
#include<list>
#include<stdexcept>
using namespace std;
class Graph
{
public:
	Graph(int V)
	{
		this->V_ = V;
		if (V < 0)
		{
			throw invalid_argument("Number of vertices must be nonnegative");
		}
		this->E_ = 0;
		adj_ = vector<list<int>>(V);
	}
	Graph(string filename)
	{
		try
		{
			ifstream input(filename);
			E_ = 0;
			if (input)
			{
				int NE;
				input >> V_ >> NE;
				if (V_ < 0)
				{
					throw invalid_argument("number of vertices in a Graph must be nonnegative");
				}
				if (NE < 0)
				{
					throw invalid_argument("number of edges in a Graph must be nonnegative");
				}
				adj_.resize(V_);
				int v, w;
				for (int i = 0; i < NE; i++)
				{
					input >> v >> w;
					validateVertex(v);
					validateVertex(w);
					addEdge(v, w);
				}
			}
			input.close();
		}
		catch (const exception&)
		{
			throw invalid_argument("invalid input format in Graph constructor");
		}
	}
	int V()
	{
		return V_;
	}
	int E()
	{
		return E_;
	}
	void addEdge(int v, int w)
	{
		validateVertex(v);
		validateVertex(w);
		E_++;
		adj_[v].push_back(w);
		adj_[w].push_back(v);

	}
	list<int> adj(int v)
	{
		validateVertex(v);
		adj_[v].reverse();
		return adj_[v];
	}
	int degree(int v)
	{
		validateVertex(v);
		return adj_[v].size();
	}
private:
	int V_;
	int E_ = 0;
	vector<list<int>> adj_;
	void validateVertex(int v)
	{
		if (v < 0 || v >= V_)
		{
			cout << "vertex " << v << " is not between 0 and " << V_ - 1 << endl;
		}
	}
};