#pragma once
#include <vector>
#include <stdexcept>
#include "Graph.h"
class DepthFirstSearch
{
public:
	DepthFirstSearch(Graph *G, int s)
	{
		marked_ = vector<bool>(G->V());
		validateVertex(s);
		dfs(G, s);
	}
	bool marked(int v)
	{
		validateVertex(v);
		return marked_[v];
	}
	int count()
	{
		return count_;
	}
private:
	vector<bool> marked_; // marked[v] = is there an s-v path?
	int count_ = 0; // number of vertices connected to s
	void dfs(Graph *G, int v)
	{
		count_++;
		marked_[v] = true;
		for (int w : G->adj(v))
		{
			if (!marked_[w])
			{
				dfs(G, w);
			}
		}
	}
	void validateVertex(int v)
	{
		int V = (int)marked_.size();
		if (v < 0 || v >= V)
		{
			cout << "vertex " << v << " is not between 0 and " << V - 1 << endl;
		}
	}
};