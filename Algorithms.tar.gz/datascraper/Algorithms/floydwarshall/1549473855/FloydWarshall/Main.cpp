#include "Intestazione.h"

int main(int argc, char** argv) {
	main_mpi(argc, argv);
	return 0;
}