#pragma once
void main_opencl();
void main_openmp();
int main_mpi(int argc, char** argv);