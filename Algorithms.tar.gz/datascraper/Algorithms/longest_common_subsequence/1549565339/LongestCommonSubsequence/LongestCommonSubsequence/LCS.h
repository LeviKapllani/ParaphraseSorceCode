#pragma once
#include<string>
struct LCS
{
	static int lcs(std::string X, std::string Y, int m, int n);
};