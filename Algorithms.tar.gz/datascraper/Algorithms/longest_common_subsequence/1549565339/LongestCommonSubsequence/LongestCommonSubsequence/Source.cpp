#include<iostream>
#include "LCS.h"

int main()
{
	std::string s1 = "AGGTAB";
	std::string s2 = "GXTXAYB";

	std::cout << "Length of LCS is" << " " << LCS::lcs(s1, s2, (int)s1.size(), (int)s2.size()) << std::endl;
	getchar();
	return 0;
}