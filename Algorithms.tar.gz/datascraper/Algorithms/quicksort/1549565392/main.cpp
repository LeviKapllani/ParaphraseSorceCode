#include <iostream>

template<class T>
void quickSort(T *, int, int);

template<class T>
void swap(T *a, T *b);

int main() {
  double arr[] = {1.55, 3.45, 4, 7, 1, 2, 3, 10, 34, 123, 43, 21, 43, 54, 12};
  quickSort(arr, 0, 14);

  for (double i: arr) {
    std::cout << i << " ";
  }

  return 0;
}

template<class T>
void swap(T &a, T &b) {
  T temp = a;
  a = b;
  b = temp;
}

template<class T>
int partition(T *arr, int start, int end) {
  int lIndex = start - 1, rIndex = end + 1;
  T pivot = arr[(start + end) / 2];

  while (lIndex < rIndex) {
    while (arr[++lIndex] < pivot);
    while (arr[--rIndex] > pivot);
    if (lIndex >= rIndex) break;
    swap(arr[lIndex], arr[rIndex]);
  }
  return rIndex;
}

template<class T>
void quickSort(T *arr, int start, int end) {
  int part = partition(arr, start, end);
  if (start < part) quickSort(arr, start, part);
  if (part + 1 < end) quickSort(arr, part + 1, end);
}

