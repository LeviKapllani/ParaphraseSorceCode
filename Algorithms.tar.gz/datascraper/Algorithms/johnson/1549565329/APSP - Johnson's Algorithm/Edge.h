#pragma once

namespace MQ
{
	class Edge
	{
	public:
		int u, v, w;
	};
};