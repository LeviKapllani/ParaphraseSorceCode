#pragma once
#pragma once

#include "adjacency_list.h"

class modify_graph
{
public:
   modify_graph();
   ~modify_graph();
   void fill_node_zero(adjacency_list* graph);
};

