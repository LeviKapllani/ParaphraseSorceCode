#pragma once

extern int infinity;

