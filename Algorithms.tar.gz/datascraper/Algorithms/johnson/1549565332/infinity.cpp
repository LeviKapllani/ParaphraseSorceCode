#include "infinity.h"

#include <limits>

int infinity = std::numeric_limits<int>::max();

