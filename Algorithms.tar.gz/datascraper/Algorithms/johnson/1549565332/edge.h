#pragma once

class edge
{
public:
   int _tail;
   int _head;
   int _cost;
   edge();
   ~edge();
};

