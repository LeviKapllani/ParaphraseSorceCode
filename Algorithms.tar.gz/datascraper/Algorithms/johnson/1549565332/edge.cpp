#include "edge.h"


edge::edge()
{
   _tail = (0);
   _head = (0);
   _cost = (0);
}


edge::~edge()
{
}
